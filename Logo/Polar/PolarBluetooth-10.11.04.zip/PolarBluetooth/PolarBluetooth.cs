﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


using System.IO.Ports;
using System.Windows.Forms;


//jussi.virkkala@neuroupdate.com
//2010-07-30 First version

namespace PolarBluetooth
{

    class PolarBluetooth
    {
        public string sFile,sXLS,sTXT;
        SerialPort mySerialPort;
        static System.IO.StreamWriter fXLS;
        static System.IO.StreamWriter fTXT;
        public void Open(string port)
        {
            mySerialPort = new SerialPort(port);

            mySerialPort.BaudRate = 115200;
            mySerialPort.Parity = Parity.None;
            mySerialPort.StopBits = StopBits.One;
            mySerialPort.DataBits = 8;
            mySerialPort.Handshake = Handshake.None;

            mySerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            mySerialPort.Open();
            string s;
            DateTime d;
            d = DateTime.Now;
            s = Application.ExecutablePath;
            sFile = s.Substring(0, s.Length - 4)+"-"+d.ToString("yyyy.MM.dd-HH.mm.ss") ;

            sXLS=sFile+".xls";
            fXLS = new System.IO.StreamWriter(sFile + ".xls");
            //2010-11-04 Status
            fXLS.WriteLine("Time\tHeader\tSize\tCheck\tIndex\tStatus\tBPM\tRRI(ms)");
            sTXT = sFile + ".txt";
            fTXT = new System.IO.StreamWriter(sFile + ".txt");
            dDate = d;
            iBPM = -1;
            iRRI = 0;
            iSize = -1;
           }

        public void Close()
        {
            mySerialPort.Close();
            fXLS.Close();
            fTXT.Close();
            if (iSize == -1)
            {
                File.Delete(sXLS);
                File.Delete(sTXT);
            }
        }

        public DateTime Time()
        {
            return dDate;
        }

        public Boolean Beat()
        {
            if (iBeat>0) return true;
            else return false;
        }

        public int Bat()
        {
            return iBattery;
        }

        public int BPM()
        {
            return iBPM;
        }

        public int Index()
        {
            return iIndex;
        }

        public string Header()
        {
            string s;
            s = iHeader.ToString()+","+iStatus.ToString();
            return s;
        }

        public int RRI()
        {
            return iRRI;
        }
        static int iHeader, iSize, iCheck, iIndex, iStatus, iBPM,iRRI;
        static int iBattery, iBeat;
        static DateTime dDate;
        //2010-07-31 Event on received
        private static void DataReceivedHandler(
                        object sender,
                        SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            string sRow;

            //Atleast 6 bytes
            if (sp.BytesToRead > 5)
            {
                iHeader = sp.ReadByte(); //always 254
                iSize = sp.ReadByte(); //size of block including bHeader, always even (8, 10, 12), different number of RRI
                iCheck = sp.ReadByte(); //255-bSize
                iIndex = sp.ReadByte(); //index: 0-15 (seconds?), first is 1
//2010-08-05 iBattery changed to iSttus
                iStatus = sp.ReadByte(); //status bit 1BBP0001, thus 128+64+16+1=209 beats (P=16) detected (BA=2) , 193 no beats
                iBeat= (iStatus >> 4) & 1;
                iBattery = (iStatus >> 5) & 3;
                iBPM= sp.ReadByte(); //beats per minutes, some averaging?

                dDate = DateTime.Now;
                sRow = dDate.ToString("HH:mm:ss")+(char)9+iHeader.ToString() + (char)9 + iSize.ToString() + (char)9 + iCheck.ToString() + (char)9 + iIndex.ToString() + (char)9 + iStatus.ToString()+(char) 9 + iBPM.ToString(); 
               
                for (int i = 7; i < iSize; i = i + 2) //different number of RRI intervals
                {
                    iRRI = sp.ReadByte() * 256 + sp.ReadByte(); //RRI (ms) 
                    fTXT.WriteLine(iRRI.ToString());
                    sRow = sRow + (char) 9 + iRRI.ToString();
                }
                
                fXLS.WriteLine(sRow);
            }

        }

    }
}
