﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


//jussi.virkkala@neuroupdate.com
//2010-08-09

namespace PolarBluetooth
{
    public partial class Form1 : Form
    {
        PolarBluetooth b = new PolarBluetooth();

        public Form1()
        {
            InitializeComponent();
        }

        int IndexOld;

        #region
        #endregion
        private void timer1_Tick(object sender, EventArgs e)
        {
            int BPM,RRI,index;


            DateTime d;
            double dif;

            d=b.Time();
            dif = DateTime.Now.ToOADate()-d.ToOADate();
            if ((cReconnect.Checked) & (dif> (10.0 / 24.0 / 3600.0)))
            {
                OpenClick();
                OpenClick();
                return;
            }

            BPM = b.BPM();
            if (b.RRI() > 0)
            {
                RRI = 60000/b.RRI();
            }
            else RRI = 0;
            d=b.Time();
            tRRI.Text = RRI.ToString();
            bBPM1.Text = BPM.ToString();
            bBPM2.Text = BPM.ToString();
            tHeader.Text = b.Header();
            tTime.Text = d.ToString("HH:mm:ss");
            int bat;
            bat = b.Bat();
            textBox2.Text=bat.ToString();
            if (b.Beat())
                checkBox1.Checked=true;
            else
                checkBox1.Checked=false;
            
            int Percentage;
            Percentage=Convert.ToInt16(100*(Convert.ToDouble(BPM)/180.0));

            Color ba;
            ba = Color.LightGray;
            if (Percentage>=90)
                    ba= Color.Red;
            if (Percentage>=80)
                    ba= Color.Yellow;
            if (Percentage>=70)
                    ba= Color.Green;
            if (Percentage >= 60)
                    ba= Color.Blue;

            bBPM1.BackColor = ba;
            bBPM2.BackColor = ba;


            tMaxPercentage.Text = Percentage.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        #if PocketPC
        #endif

        }

        private void OpenClick()
        {
            Cursor.Current = Cursors.WaitCursor;
            if (bOpen.Text == "&Open")
            {
                bOpen.Text = "&Close";
                b.Open(tCOM.Text);
                timer1.Enabled = true;
                tFile.Text = b.sFile;
            }
            else
            {
                bBPM1.Text="BPM";
                bBPM2.Text = "BPM";
                bOpen.Text = "&Open";
                timer1.Enabled = false;
                b.Close();
            }
            Cursor.Current = Cursors.Default;

        }

        private void bOpen_Click(object sender, EventArgs e)
        {
            OpenClick();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void bBPM_Click(object sender, EventArgs e)
        {
            bBPM2.Visible = true;
        }

        private void bBPM2_Click(object sender, EventArgs e)
        {
            bBPM2.Visible = false;
        }

        private void HEADER_TextChanged(object sender, EventArgs e)
        {

        }

        private void tMaxPercentage_TextChanged(object sender, EventArgs e)
        {

        }
    }
}