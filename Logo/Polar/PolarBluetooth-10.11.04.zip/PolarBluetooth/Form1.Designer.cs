﻿namespace PolarBluetooth
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bOpen = new System.Windows.Forms.Button();
            this.tRRI = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tCOM = new System.Windows.Forms.TextBox();
            this.tFile = new System.Windows.Forms.TextBox();
            this.tTime = new System.Windows.Forms.TextBox();
            this.cReconnect = new System.Windows.Forms.CheckBox();
            this.bBPM1 = new System.Windows.Forms.Button();
            this.bBPM2 = new System.Windows.Forms.Button();
            this.tHeader = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tMaxPercentage = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // bOpen
            // 
            this.bOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bOpen.Location = new System.Drawing.Point(3, 44);
            this.bOpen.Name = "bOpen";
            this.bOpen.Size = new System.Drawing.Size(92, 36);
            this.bOpen.TabIndex = 0;
            this.bOpen.Text = "&Open";
            this.bOpen.UseVisualStyleBackColor = true;
            this.bOpen.Click += new System.EventHandler(this.bOpen_Click);
            // 
            // tRRI
            // 
            this.tRRI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tRRI.Location = new System.Drawing.Point(86, 90);
            this.tRRI.Multiline = true;
            this.tRRI.Name = "tRRI";
            this.tRRI.Size = new System.Drawing.Size(67, 26);
            this.tRRI.TabIndex = 13;
            this.tRRI.Text = "BPM (fast)";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tCOM
            // 
            this.tCOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tCOM.Location = new System.Drawing.Point(3, 2);
            this.tCOM.Multiline = true;
            this.tCOM.Name = "tCOM";
            this.tCOM.Size = new System.Drawing.Size(91, 27);
            this.tCOM.TabIndex = 5;
            this.tCOM.Text = "COM6";
            // 
            // tFile
            // 
            this.tFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tFile.Location = new System.Drawing.Point(2, 163);
            this.tFile.Multiline = true;
            this.tFile.Name = "tFile";
            this.tFile.Size = new System.Drawing.Size(230, 59);
            this.tFile.TabIndex = 6;
            this.tFile.Text = "Filename";
            // 
            // tTime
            // 
            this.tTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tTime.Location = new System.Drawing.Point(2, 91);
            this.tTime.Multiline = true;
            this.tTime.Name = "tTime";
            this.tTime.Size = new System.Drawing.Size(68, 26);
            this.tTime.TabIndex = 7;
            this.tTime.Text = "Time";
            // 
            // cReconnect
            // 
            this.cReconnect.AutoSize = true;
            this.cReconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cReconnect.Location = new System.Drawing.Point(117, 4);
            this.cReconnect.Name = "cReconnect";
            this.cReconnect.Size = new System.Drawing.Size(116, 20);
            this.cReconnect.TabIndex = 10;
            this.cReconnect.Text = "&Auto reconnect";
            this.cReconnect.UseVisualStyleBackColor = true;
            // 
            // bBPM1
            // 
            this.bBPM1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bBPM1.Location = new System.Drawing.Point(119, 44);
            this.bBPM1.Name = "bBPM1";
            this.bBPM1.Size = new System.Drawing.Size(114, 36);
            this.bBPM1.TabIndex = 11;
            this.bBPM1.Text = "&BPM";
            this.bBPM1.UseVisualStyleBackColor = true;
            this.bBPM1.Click += new System.EventHandler(this.bBPM_Click);
            // 
            // bBPM2
            // 
            this.bBPM2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bBPM2.Location = new System.Drawing.Point(3, 86);
            this.bBPM2.Name = "bBPM2";
            this.bBPM2.Size = new System.Drawing.Size(230, 87);
            this.bBPM2.TabIndex = 12;
            this.bBPM2.Text = "BPM";
            this.bBPM2.UseVisualStyleBackColor = true;
            this.bBPM2.Visible = false;
            this.bBPM2.Click += new System.EventHandler(this.bBPM2_Click);
            // 
            // tHeader
            // 
            this.tHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tHeader.Location = new System.Drawing.Point(3, 131);
            this.tHeader.Multiline = true;
            this.tHeader.Name = "tHeader";
            this.tHeader.Size = new System.Drawing.Size(67, 26);
            this.tHeader.TabIndex = 13;
            this.tHeader.Text = "Header";
            this.tHeader.TextChanged += new System.EventHandler(this.HEADER_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(3, 255);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(230, 135);
            this.textBox1.TabIndex = 14;
            this.textBox1.Text = "Connects to Polar bluetooth transmitter (www.sports-tracker.com). Writes .xls and" +
                " .txt (IBI) files. ";
            // 
            // tMaxPercentage
            // 
            this.tMaxPercentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tMaxPercentage.Location = new System.Drawing.Point(165, 91);
            this.tMaxPercentage.Multiline = true;
            this.tMaxPercentage.Name = "tMaxPercentage";
            this.tMaxPercentage.Size = new System.Drawing.Size(67, 26);
            this.tMaxPercentage.TabIndex = 15;
            this.tMaxPercentage.Text = "%180";
            this.tMaxPercentage.TextChanged += new System.EventHandler(this.tMaxPercentage_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(86, 131);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(67, 26);
            this.textBox3.TabIndex = 16;
            this.textBox3.Text = "Header";
            this.textBox3.Visible = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new System.Drawing.Point(9, 227);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(93, 17);
            this.checkBox1.TabIndex = 17;
            this.checkBox1.Text = "Beat detected";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(165, 223);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(67, 26);
            this.textBox2.TabIndex = 18;
            this.textBox2.Text = "BAT";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(234, 396);
            this.Controls.Add(this.bBPM2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.tMaxPercentage);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tHeader);
            this.Controls.Add(this.bBPM1);
            this.Controls.Add(this.cReconnect);
            this.Controls.Add(this.tTime);
            this.Controls.Add(this.tFile);
            this.Controls.Add(this.tCOM);
            this.Controls.Add(this.tRRI);
            this.Controls.Add(this.bOpen);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "PolarBT-2010.11.04";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bOpen;
        private System.Windows.Forms.TextBox tRRI;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox tCOM;
        private System.Windows.Forms.TextBox tFile;
        private System.Windows.Forms.TextBox tTime;
        private System.Windows.Forms.CheckBox cReconnect;
        private System.Windows.Forms.Button bBPM1;
        private System.Windows.Forms.Button bBPM2;
        private System.Windows.Forms.TextBox tHeader;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox tMaxPercentage;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}

